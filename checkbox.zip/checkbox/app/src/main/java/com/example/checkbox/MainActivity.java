package com.example.checkbox;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

     CheckBox android, java , python, c, cc , javascript, html ;
     Button button;
     TextView result;
     ArrayList<String> mresult;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        android = (CheckBox) findViewById(R.id.android);
        java = (CheckBox) findViewById(R.id.java);
        python = (CheckBox) findViewById(R.id.python);
        c = (CheckBox) findViewById(R.id.c);
        cc = (CheckBox) findViewById(R.id.cc);
        javascript = (CheckBox) findViewById(R.id.javascript);
        html = (CheckBox) findViewById(R.id.html);

        button = (Button) findViewById(R.id.button);
        result = (TextView) findViewById(R.id.result);
        mresult = new ArrayList<>();
        result.setEnabled(false);

        android.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (android.isChecked())
                    mresult.add("Android");
                else
                    mresult.remove("Android");
            }
        });
        java.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (java.isChecked())
                    mresult.add("Java");
                else
                    mresult.remove("Java");
            }
        });
        python.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (python.isChecked())
                    mresult.add("Python");
                else
                    mresult.remove("Python");
            }
        });
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (c.isChecked())
                    mresult.add("C");
                else
                    mresult.remove("C");
            }
        });
        cc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cc.isChecked())
                    mresult.add("C++");
                else
                    mresult.remove("C++");
            }
        });
        javascript.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (javascript.isChecked())
                    mresult.add("Javascript");
                else
                    mresult.remove("Javascript");
            }
        });
        html.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (html.isChecked())
                    mresult.add("HTML");
                else
                    mresult.remove("HTML");
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder stringBuilder = new StringBuilder();
                for (String s : mresult)
                    stringBuilder.append(s).append("\n");
                result.setText(stringBuilder.toString());
                result.setEnabled(false);

            }
        });



    }
}